describe('Find Spaceship', function() {
    it('should return [2, 7] for the given map', function() {
        const map = '........\n........\n.......X\n........\n........';
        const expectedResult = [2, 7];
        const result = findSpaceship(map);
        expect(result).toEqual(expectedResult);
    });

    it('should return "Spaceship lost forever." if the spaceship is not found', function() {
        const map = '........\n........\n........\n........\n........';
        const expectedResult = "Spaceship lost forever.";
        const result = findSpaceship(map);
        expect(result).toEqual(expectedResult);
    });
});
