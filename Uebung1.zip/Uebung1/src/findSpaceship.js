// StringCalculator.js

function findSpaceship(map) {
    const rows = map.split('\n');
    let position = "Spaceship lost forever.";

    rows.some((row, y) => {
        const x = row.indexOf('X');
        if (x !== -1) {
            position = [y, x];
            return true; 
        }
    });

    return position;
}

